const menuToggle = document.querySelector('[data-menu-toggle]');
const navMenu = document.querySelector('[data-nav-menu]');

if (menuToggle && navMenu) {
  menuToggle.addEventListener('click', () => {
    const isOpen = navMenu.classList.toggle('is-open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });
}

const contactForm = document.querySelector('[data-contact-form]');
if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const button = contactForm.querySelector('button[type="submit"]');
    const oldText = button.textContent;
    button.textContent = 'Сообщение подготовлено';
    button.disabled = true;
    setTimeout(() => {
      button.textContent = oldText;
      button.disabled = false;
      contactForm.reset();
    }, 1800);
  });
}
